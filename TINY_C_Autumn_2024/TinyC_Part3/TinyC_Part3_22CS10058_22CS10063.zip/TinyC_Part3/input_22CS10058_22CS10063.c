
int main() {
    int a;
    int b = 2.5*5;
    a = 6.5+7;
    return 0;
}